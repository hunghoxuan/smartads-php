<?php
use common\widgets\BulkButtonWidget;
use yii\helpers\Html;
use common\components\FHtml;
use common\components\Helper;
use kartik\nav\NavX;
use kartik\dropdown\DropdownX;
use yii\helpers\BaseInflector;

?>

<div class='row'>
    <div class='col-md-12'>
           <span class="pull-left"><?= FHtml::buttonSearch() ?></span>
    </div>
</div>