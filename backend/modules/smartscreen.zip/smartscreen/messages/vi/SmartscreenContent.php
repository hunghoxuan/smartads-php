<?php

return [
            'ID' => 'ID',
            'Title' => 'Title',
            'Url' => 'Url',
            'Description' => 'Description',
            'Type' => 'Type',
            'Expire Date' => 'Expire Date',
            'Sort Order' => 'Sort Order',
            'Owner ID' => 'Owner ID',
            'Is Active' => 'Is Active',
            'Created Date' => 'Created Date',
            'Modified Date' => 'Modified Date',
            'Application ID' => 'Application ID',
        ];
?>