<?php

return [
            'ID' => 'ID',
            'Name' => 'Name',
            'Background Color' => 'Background Color',
            'Layout ID' => 'Layout ID',
            'Percent Width' => 'Percent Width',
            'Percent Height' => 'Percent Height',
            'Margin Top' => 'Margin Top',
            'Margin Left' => 'Margin Left',
            'Content Layout' => 'Content Layout',
            'Created Date' => 'Created Date',
            'Modified Date' => 'Modified Date',
            'Application ID' => 'Application ID',
            'File' => 'File',
            'Content' => 'Content',
            'Content ID' => 'Content ID',
            'Font Size' => 'Font Size',
            'Font Color' => 'Font Color',
            'Alignment' => 'Alignment',
            'Sort Order' => 'Sort Order',
            'Is Active' => 'Is Active',
        ];
?>