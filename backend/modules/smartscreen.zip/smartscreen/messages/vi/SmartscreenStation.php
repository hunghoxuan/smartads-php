<?php

return [
            'ID' => 'ID',
            'Name' => 'Name',
            'Ime' => 'Ime',
            'Status' => 'Status',
            'Screen Name' => 'Screen Name',
            'Macaddress' => 'Macaddress',
            'License Key' => 'License Key',
            'Branch ID' => 'Branch ID',
            'Script ID' => 'Script ID',
            'Script Update' => 'Script Update',
            'Created Date' => 'Created Date',
            'Application ID' => 'Application ID',
        ];
?>