<?php

return [
            'ID' => 'ID',
            'Device ID' => 'Device ID',
            'Layout ID' => 'Layout ID',
            'Content ID' => 'Content ID',
            'Frame ID' => 'Frame ID',
            'Start Time' => 'Start Time',
            'Date' => 'Date',
            'Type' => 'Type',
            'Application ID' => 'Application ID',
        ];
?>