<?php

return [
            'ID' => 'ID',
            'Object ID' => 'Object ID',
            'File' => 'File',
            'Description' => 'Description',
            'File Kind' => 'File Kind',
            'File Size' => 'File Size',
            'File Duration' => 'File Duration',
            'Is Active' => 'Is Active',
            'Sort Order' => 'Sort Order',
            'Created Date' => 'Created Date',
            'Created User' => 'Created User',
            'Application ID' => 'Application ID',
        ];
?>