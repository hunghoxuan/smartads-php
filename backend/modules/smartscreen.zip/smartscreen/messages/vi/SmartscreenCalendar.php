<?php

return [
            'ID' => 'ID',
            'Code' => 'Code',
            'Name' => 'Name',
            'Description' => 'Description',
            'Date' => 'Date',
            'Time' => 'Time',
            'Device ID' => 'Device ID',
            'Location' => 'Location',
            'Type' => 'Type',
            'Owner Name' => 'Owner Name',
            'Created Date' => 'Created Date',
            'Created User' => 'Created User',
            'Modified Date' => 'Modified Date',
            'Modified User' => 'Modified User',
            'Application ID' => 'Application ID',
        ];
?>