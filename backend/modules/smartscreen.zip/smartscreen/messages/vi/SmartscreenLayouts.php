<?php

return [
            'ID' => 'ID',
            'Name' => 'Name',
            'Description' => 'Description',
            'Sort Order' => 'Sort Order',
            'Is Active' => 'Is Active',
            'Frame Header' => 'Frame Header',
            'Frame Sidebar' => 'Frame Sidebar',
            'Frame Main' => 'Frame Main',
            'Frame Footer' => 'Frame Footer',
            'Created Date' => 'Created Date',
            'Modified Date' => 'Modified Date',
            'Appilication ID' => 'Appilication ID',
        ];
?>