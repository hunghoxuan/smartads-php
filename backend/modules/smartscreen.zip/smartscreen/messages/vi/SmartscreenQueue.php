<?php

return [
            'ID' => 'ID',
            'Code' => 'Code',
            'Name' => 'Name',
            'Ticket' => 'Ticket',
            'Counter' => 'Counter',
            'Service' => 'Service',
            'Status' => 'Status',
            'Note' => 'Note',
            'Device ID' => 'Device ID',
            'Is Active' => 'Is Active',
            'Sort Order' => 'Sort Order',
            'Created Date' => 'Created Date',
            'Created User' => 'Created User',
            'Application ID' => 'Application ID',
        ];
?>