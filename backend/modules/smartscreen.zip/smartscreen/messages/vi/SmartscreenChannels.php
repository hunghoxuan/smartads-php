<?php

return [
            'ID' => 'ID',
            'Name' => 'Name',
            'Description' => 'Description',
            'Image' => 'Image',
            'Content' => 'Content',
            'Is Active' => 'Is Active',
            'Created Date' => 'Created Date',
            'Created User' => 'Created User',
            'Application ID' => 'Application ID',
        ];
?>