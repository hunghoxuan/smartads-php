# pure-css-js-slider

A pure CSS/JS slider layout developed for Toptal engineering blog article.

Working demo: https://stefan.lynxdev.io/projects/fullscreen-slider/
